#include "chatdialog.h"
#include "loginwindow.h"
#include <QHostAddress>
#include <cstdlib>
#include <cstring>
#include <QtAlgorithms>
#include <QDateTime>
#include <QTcpSocket>
#include <QStringList>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QString>
#include <QMessageBox>
#include <QFontComboBox>
#include <QtDebug>
#include "global.h"

/* constructor */
Chat::Chat(QWidget *parent):QDialog(parent)
{
	setupUi(this);

	leaders = new QStringList;
	fleaders = new QStringList;
	model = new QStringListModel(this);
	fmodel = new QStringListModel(this);
	namelist->setEditTriggers(QAbstractItemView::NoEditTriggers);
	forbidlist->setEditTriggers(QAbstractItemView::NoEditTriggers);
	myname->setText(user_name);
	flag = 0;

	if(user_name != QString("admin")){
		kick->hide();
		auditor->hide();
		noauditor->hide();
		forbidlist->hide();
	}
	else{
		connect(kick,SIGNAL(clicked()),this,SLOT(kickuser()));
		connect(auditor,SIGNAL(clicked()),this,SLOT(forbid()));
		connect(noauditor,SIGNAL(clicked()),this,SLOT(noforbid()));
	}
		
	connect(tohim,SIGNAL(clicked()),this,SLOT(changeto()));
	connect(send,SIGNAL(clicked()),this,SLOT(sendMsg()));
	connect(gol_tcpSocket,SIGNAL(readyRead()),this,SLOT(recvMsg()));
	connect(gol_tcpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(error()));
	connect(clear,SIGNAL(clicked()),this,SLOT(clearbrowser()));
	connect(allchat,SIGNAL(clicked()),this,SLOT(chattoall()));
	connect(quit, SIGNAL(clicked()),this,SLOT(quit_chat()));
	connect(invisible,SIGNAL(clicked()),this,SLOT(changestate()));

	QTextStream out(gol_tcpSocket);
	out<<QString("0004test");
}
/* forbid the user to send massage */
void Chat::forbid()
{
	int row = namelist->currentIndex().row();
	QStringList list = model->stringList();
	QString name = list.at(row);
		
	int len = name.size()+12;
	char buf[5];

	toString(buf,len);
	QString forbidMsg = QString("%1%2:#:%3:%4")
		.arg(buf)
		.arg("auditor")
		.arg(name)
		.arg("1");

	QTextStream out(gol_tcpSocket);
	out<<forbidMsg;
	*fleaders = fmodel->stringList();
	fleaders->append(name);
	fmodel->setStringList(*fleaders);
	forbidlist->setModel(fmodel);
}
/* allow the user to send the massage */
void Chat::noforbid()
{
	int row = forbidlist->currentIndex().row();
	QStringList list = fmodel->stringList();
	QString name = list.at(row);
		
	int len = name.size()+12;
	char buf[5];

	toString(buf,len);
	QString forbidMsg = QString("%1%2:#:%3:%4")
		.arg(buf)
		.arg("auditor")
		.arg(name)
		.arg("0");

	QTextStream out(gol_tcpSocket);
	out<<forbidMsg;
	fmodel->removeRows(forbidlist->currentIndex().row(),1);
}
/* kick the user */
void Chat::kickuser()
{
	int row = namelist->currentIndex().row();
	QStringList list = model->stringList();
	QString name = list.at(row);

	int len = name.size()+9;
	char buf[5];

	toString(buf,len);
	QString kickMsg = QString("%1%2:#:#:%3")
		.arg(buf)
		.arg("kick")
		.arg(name);

	QTextStream out(gol_tcpSocket);
	out<<kickMsg;
}
/* connect to host error */
void Chat::error()
{
	QMessageBox::critical(this, "socket error",gol_tcpSocket->errorString());
	gol_tcpSocket->close();
}
/*  clear the  chat browser */
void Chat::clearbrowser()
{
	chatcontent->clear();
}
/*  change the state of the user */
void Chat::changestate()
{
	QString button_text = invisible->text();
	int len = user_name.size()+9;
	char buf[5];

	toString(buf,len);
	QString inviMsg = QString("%1%2:%3:%4:")
		.arg(buf)
		.arg("invi")
		.arg(user_name)
		.arg("#");

	if(button_text == QString::fromLocal8Bit("隐身")){
		invisible->setText(QString::fromLocal8Bit("上线"));
		inviMsg += QString("1");
	}
	if(button_text == QString::fromLocal8Bit("上线")){
		invisible->setText(QString::fromLocal8Bit("隐身"));
		inviMsg += QString("0");
	}

	QTextStream out(gol_tcpSocket);
	out<<inviMsg;
}
/* refresh the user list */
int Chat::refreshlist(char type,char *data)
{
	*leaders = model->stringList();
	if(type == 'A'){
		leaders->append(QString(data));
	}
	else if(type == 'L'){
		char *p = data;
		while((p=strchr(data,'\n')) != NULL){
			*p = '\0';
			if(user_name != QString(data)){
				*leaders<<data;
				data = p+1;
			}
		}
	}
	else if(type == 'D'){
		QStringList::iterator i = qFind(leaders->begin(),leaders->end(),data);
		leaders->erase(i);
	}
	model->setStringList(*leaders);
	namelist->setModel(model);
	return 0;
}
/* change the user chat to */
void Chat::changeto()
{
	int row = namelist->currentIndex().row();
	QStringList list = model->stringList();
	QString name = list.at(row);

	if(user_name != name)
		towho->setText(name);
}
/* chat to all */
void Chat::chattoall()
{
	towho->setText(QString("all"));
}
/* show the chat massage */
int Chat::show_msg(const char *s, const char *d, const char *msg)
{

	QDateTime nowDateTime = QDateTime::currentDateTime();

	chatcontent->append(
		QString("\n[%1] %2 %3 %4 %5\n%6")
		.arg(nowDateTime.toString("yyyy-MM-dd  hh:mm:ss"))
		.arg(s)
		.arg(QString::fromLocal8Bit("对"))
		.arg(d)
		.arg(QString::fromLocal8Bit("说道:"))
		.arg(msg) );
	chatcontent->moveCursor(QTextCursor::End);
	return 0;
}
/* save the chat  record */
int Chat::save_chat_record()
{
	QString record = chatcontent->toPlainText();
	QString path("./ChatRecord/");
	path += user_name;
	QFile *file = new QFile(path);
	file->open(QIODevice::WriteOnly | QIODevice::Append);
	QTextStream out(file);
	out<<record;
	file->close();
	return 0;
}
/* quit the chat  dialog */
void Chat::quit_chat()
{
	save_chat_record();		/** save chat record **/
	QString sMsg("0010quit:#:#:#");
	QTextStream out(gol_tcpSocket);
	out<<sMsg;
	gol_tcpSocket->close();
	close();
}
/* receive the massage from server */
void Chat::recvMsg()
{
	int n;
	char buf[256];
	bzero(buf,sizeof(buf));
	n = gol_tcpSocket->read(buf,sizeof(buf));
	buf[n]='\0';

	parse_command(buf+4);
	qDebug()<<buf;
	if(strcmp(cmd, "chat")==0){
		show_msg(source, dest, chat_data);	/** display msg **/
	}
	else if(strcmp(cmd, "addlist")==0){
		refreshlist('A',chat_data);
	}
	else if(strcmp(cmd, "dellist")==0){
		refreshlist('D',chat_data);
	}
	else if(strcmp(cmd, "list")==0){
		refreshlist('L',chat_data);
	}
	else if(strcmp(cmd, "answer")==0){

	}
	else if(strcmp(cmd,"invi")==0){
		if(strcmp(chat_data,"1ok")==0)
			state->setText(QString::fromLocal8Bit("隐身"));
		else if(strcmp(chat_data,"0ok")==0)
			state->setText(QString::fromLocal8Bit("在线"));
		else
		{
		}
	}
	else if(strcmp(cmd,"kick") == 0){
		quit_chat();
	}
	else if(strcmp(cmd,"auditor") == 0){
		if(strcmp(chat_data,"1") == 0)
			flag =1;
		else
			flag = 0;
	}
}
/* send the massage */
void Chat::sendMsg()
{
	QString tmp = sendtext->toPlainText();
	if(tmp.isEmpty())
	{
		QMessageBox::warning(this, "error", QString::fromLocal8Bit("发送的内容不能为空"));
		return;
	}
	int len = tmp.size() +4 +4 +6 +towho->text().size();
	if(len >= 160){
		QMessageBox::warning(this, "error", QString::fromLocal8Bit("发送的内容太长"));
		sendtext->clear();
		return;
	}

	char buf[5];

	toString(buf,len);
	QString sMsg = QString("%1%2:%3:%4:%5")
		.arg(buf)
		.arg("chat")
		.arg(user_name)
		.arg(towho->text())
		.arg(tmp);
	if(flag == 0){
		show_msg(qPrintable(user_name), 
				 qPrintable(towho->text()), 
				 qPrintable(tmp));	/** display msg **/
		QTextStream out(gol_tcpSocket);
		out<<sMsg;
	}
	sendtext->clear();
	if(flag == 1){
		QMessageBox::warning(this, "error", QString::fromLocal8Bit("你已经被禁言"));
		return;
	}
}
