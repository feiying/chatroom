#include "loginwindow.h"
#include "registerpage.h"
#include <QtDebug>
#include <QMessageBox>
#include <QHostAddress>
#include <QRegExp>
#include "global.h"

RegisterPage::RegisterPage(QWidget *parent):QDialog(parent)
{
	setupUi(this);
	connect(registerButton_1,SIGNAL(clicked()),this,SLOT(reg_to_server()));
	connect(cancelButton_1,SIGNAL(clicked()),this,SLOT(showLoginWindow()));
	tcpSocket  = new QTcpSocket(this);
	connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(rcv_from_reg()));
	//		connect(tcpSocket, SIGNAL(error(QAbstracSocket::SocketError)), this, SLOT(error()));
	//	tcpSocket->connectToHost(QHostAddress::LocalHost,8000);
	tcpSocket->connectToHost(server_ip,server_port);
#ifdef DEBUG
	qDebug() << server_ip << server_port << endl;
#endif
	login = NULL;
}
void RegisterPage::reg_to_server()
{
	QString temp_id = usrIdlineEdit->text();
	QString temp_p1 = pwdlineEdit->text();
	QString temp_p2 = rpwdlineEdit->text();
	if ((input_check(temp_id) == -1) || (input_check(temp_p1) == -1) || (temp_p1 != temp_p2))
	{
		QMessageBox::information(this,
								 tr("input state"),
								 tr("input error!only number and letter! or password input 2 times not same!! press ok renew"),
								 QMessageBox::Ok);
		/*error*/
		return ;
	}
	//	qDebug() << usrIdlineEdit->text() << pwdlineEdit->text() << rpwdlineEdit->text();
	command_usr.command = "reg";
	command_usr.source = usrIdlineEdit->text();
	command_usr.target = "server";
	command_usr.data = "";
	command_usr.data.append(  usrIdlineEdit->text() );
	command_usr.data.append("=");
	command_usr.data.append( pwdlineEdit->text());
	int len = command_usr.command.size()+ 7 + command_usr.source.size() + command_usr.target.size() + command_usr.data.size();
	char buf[5];
	toString(buf,len);
	command_usr.command = buf;
	command_usr.command.append("reg");
#ifdef DEBUG
	qDebug() << command_usr.command << command_usr.source << command_usr.target << command_usr.data << endl;
#endif
	send_to_server(command_usr, tcpSocket);
}
void RegisterPage::rcv_from_reg()
{
	int n;
	char buf[256];
	bzero(buf,sizeof(buf));
	n = tcpSocket->read(buf,sizeof(buf));
	buf[n]='\0';
	QString responseLine = QString(buf+4);
	get_command(responseLine, command_usr);
#ifdef DEBUG
	qDebug() << command_usr.command << command_usr.source << command_usr.target << command_usr.data << endl;
#endif
	if (command_usr.command == "reg" && command_usr.data == "ok" )
	{
		QMessageBox::information(this,
								 tr("reg state"),
								 tr("reg sucess press ok for login!"),
								 QMessageBox::Ok);
	}
	if (command_usr.command == "reg" && command_usr.data == "rename" )
	{
		QMessageBox::information(this,
								 tr("reg state"),
								 tr("fail to reg! press ok renew"),
								 QMessageBox::Ok);
		tcpSocket->close();
		tcpSocket->connectToHost(server_ip,server_port);
	}
}
int input_check(QString &str)
{
	QRegExp regexp("^[0-9a-zA-Z]{1,10}$");
	int result = regexp.indexIn(str);
	if(result != -1)
		return 0;
	else
		return -1;
}
int send_to_server(command &com_data, QTcpSocket* tcp)
{
	QTextStream out(tcp);
	out << com_data.command << ':' << com_data.source << ':' << com_data.target << ':' << com_data.data ;
	return 0;
}
int toString(char *a, int i)
{
	char tmp[5];
	int j = 0;
	char *p = tmp, *q;
	for(j = 0; j < 5; j++)
		tmp[j] = '0';
	while(1){
		*p = (i%10)+'0';
		p++;
		i = i/10;
		if(i == 0){
			break;
		}
	}
	p = tmp+3;
	for(q = a; p!=tmp-1; q++,p--){
		*q = *p;
	}
	*q='\0';
	return 0;
}
int get_command(QString &s, command &com_data)
{
	char *p = NULL;
	const char *q = qPrintable(s);
	int i = 0;
	char cmd[8];
	char source[30];
	char dest[30];
	char data[160];
	/** clear the cmdline **/
	bzero(cmd, sizeof(cmd));
	bzero(source, sizeof(source));
	bzero(dest, sizeof(dest));
	bzero(data, sizeof(data));

	while((p = strchr(q,':')) != NULL)
	{
		if(i >= 3)
			break;
		if(i == 0){
			strncpy(cmd, q, p-q);
			cmd[p-q]='\0';
			q = p+1;
		}
		else if(i == 1){
			strncpy(source,q, p-q);
			source[p-q]='\0';
			q = p+1;
		}
		else if(i == 2){
			strncpy(dest,q, p-q);
			dest[p-q]='\0';
			q = p+1;
		}

		i++;
	}
	strcpy(data,q);
	com_data.command = cmd;
	com_data.source = source;
	com_data.target = dest;
	com_data.data = data;

	return 0;
}

void RegisterPage::showLoginWindow()
{
	if(NULL == login)
		login= new LoginWindow();
	login->show();
	hide();
}
