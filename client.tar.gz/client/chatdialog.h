#ifndef MYDIALOG_H
#define MYDIALOG_H

#include "ui_ChatDialog.h"
#include <QTcpSocket>
#include <QStringListModel>
#include <QDialog>
class Command
{
public:
	Command();
	int parse_command(char *buf);
	int toString(char *buf, int len);
	char cmd[8];
	char source[15];
	char dest[15];
	char chat_data[160];
};

class Chat:public QDialog,public Ui_ChatDialog,public Command
{
	Q_OBJECT

public:
		Chat(QWidget *parent = 0);
		int refreshlist(char type,char *data);
		int show_msg(const char *s, const char *d, const char *msg);
		int save_chat_record();

private slots:
		void sendMsg();
		void error();
		void recvMsg();
		void clearbrowser();
		void changeto();
		void chattoall();
		void quit_chat();
		void changestate();
		void kickuser();
		void forbid();
		void noforbid();


private:
		QTcpSocket *tcpSocket;
		QString Msgbuf;
		QStringListModel *model;
		QStringListModel *fmodel;
		QStringList *leaders;
		QStringList *fleaders;
		int flag;
};
#endif
