/********************************************************************************
** Form generated from reading ui file 'loginwindow.ui'
**
** Created: Thu Oct 9 11:43:04 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_LOGINWINDOW_H
#define UI_LOGINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

class Ui_LoginWindow
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *usrlineEdit;
    QLineEdit *pwdlineEdit;
    QPushButton *loginButton;
    QPushButton *cancelButton;
    QPushButton *registerButton;
    QPushButton *serIPButton;
    QPushButton *aboutButton;

    void setupUi(QDialog *LoginWindow)
    {
    if (LoginWindow->objectName().isEmpty())
        LoginWindow->setObjectName(QString::fromUtf8("LoginWindow"));
    QSize size(304, 274);
    size = size.expandedTo(LoginWindow->minimumSizeHint());
    LoginWindow->resize(size);
    label = new QLabel(LoginWindow);
    label->setObjectName(QString::fromUtf8("label"));
    label->setGeometry(QRect(30, 40, 71, 31));
    QFont font;
    font.setPointSize(13);
    label->setFont(font);
    label_2 = new QLabel(LoginWindow);
    label_2->setObjectName(QString::fromUtf8("label_2"));
    label_2->setGeometry(QRect(30, 80, 81, 31));
    label_2->setFont(font);
    usrlineEdit = new QLineEdit(LoginWindow);
    usrlineEdit->setObjectName(QString::fromUtf8("usrlineEdit"));
    usrlineEdit->setGeometry(QRect(130, 40, 141, 27));
    pwdlineEdit = new QLineEdit(LoginWindow);
    pwdlineEdit->setObjectName(QString::fromUtf8("pwdlineEdit"));
    pwdlineEdit->setGeometry(QRect(130, 80, 141, 27));
    pwdlineEdit->setEchoMode(QLineEdit::Password);
    loginButton = new QPushButton(LoginWindow);
    loginButton->setObjectName(QString::fromUtf8("loginButton"));
    loginButton->setGeometry(QRect(50, 160, 80, 31));
    QFont font1;
    font1.setPointSize(11);
    loginButton->setFont(font1);
    cancelButton = new QPushButton(LoginWindow);
    cancelButton->setObjectName(QString::fromUtf8("cancelButton"));
    cancelButton->setGeometry(QRect(170, 160, 80, 31));
    cancelButton->setFont(font1);
    registerButton = new QPushButton(LoginWindow);
    registerButton->setObjectName(QString::fromUtf8("registerButton"));
    registerButton->setGeometry(QRect(10, 220, 80, 27));
    serIPButton = new QPushButton(LoginWindow);
    serIPButton->setObjectName(QString::fromUtf8("serIPButton"));
    serIPButton->setGeometry(QRect(110, 220, 80, 27));
    aboutButton = new QPushButton(LoginWindow);
    aboutButton->setObjectName(QString::fromUtf8("aboutButton"));
    aboutButton->setGeometry(QRect(210, 220, 80, 27));

    retranslateUi(LoginWindow);

    QMetaObject::connectSlotsByName(LoginWindow);
    } // setupUi

    void retranslateUi(QDialog *LoginWindow)
    {
    LoginWindow->setWindowTitle(QApplication::translate("LoginWindow", "Welcome to ChartRoom", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("LoginWindow", "UserID", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("LoginWindow", "PassWord", 0, QApplication::UnicodeUTF8));
    loginButton->setText(QApplication::translate("LoginWindow", "Login", 0, QApplication::UnicodeUTF8));
    cancelButton->setText(QApplication::translate("LoginWindow", "Canel", 0, QApplication::UnicodeUTF8));
    registerButton->setText(QApplication::translate("LoginWindow", "Register", 0, QApplication::UnicodeUTF8));
    serIPButton->setText(QApplication::translate("LoginWindow", "ServerIP", 0, QApplication::UnicodeUTF8));
    aboutButton->setText(QApplication::translate("LoginWindow", "About", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(LoginWindow);
    } // retranslateUi

};

namespace Ui {
    class LoginWindow: public Ui_LoginWindow {};
} // namespace Ui

#endif // UI_LOGINWINDOW_H
