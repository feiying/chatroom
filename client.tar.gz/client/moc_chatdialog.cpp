/****************************************************************************
** Meta object code from reading C++ file 'chatdialog.h'
**
** Created: Thu Oct 9 13:39:19 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "chatdialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chatdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_Chat[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
       6,    5,    5,    5, 0x08,
      16,    5,    5,    5, 0x08,
      24,    5,    5,    5, 0x08,
      34,    5,    5,    5, 0x08,
      49,    5,    5,    5, 0x08,
      60,    5,    5,    5, 0x08,
      72,    5,    5,    5, 0x08,
      84,    5,    5,    5, 0x08,
      98,    5,    5,    5, 0x08,
     109,    5,    5,    5, 0x08,
     118,    5,    5,    5, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Chat[] = {
    "Chat\0\0sendMsg()\0error()\0recvMsg()\0"
    "clearbrowser()\0changeto()\0chattoall()\0"
    "quit_chat()\0changestate()\0kickuser()\0"
    "forbid()\0noforbid()\0"
};

const QMetaObject Chat::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Chat,
      qt_meta_data_Chat, 0 }
};

const QMetaObject *Chat::metaObject() const
{
    return &staticMetaObject;
}

void *Chat::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Chat))
	return static_cast<void*>(const_cast< Chat*>(this));
    if (!strcmp(_clname, "Ui_ChatDialog"))
	return static_cast< Ui_ChatDialog*>(const_cast< Chat*>(this));
    if (!strcmp(_clname, "Command"))
	return static_cast< Command*>(const_cast< Chat*>(this));
    return QDialog::qt_metacast(_clname);
}

int Chat::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: sendMsg(); break;
        case 1: error(); break;
        case 2: recvMsg(); break;
        case 3: clearbrowser(); break;
        case 4: changeto(); break;
        case 5: chattoall(); break;
        case 6: quit_chat(); break;
        case 7: changestate(); break;
        case 8: kickuser(); break;
        case 9: forbid(); break;
        case 10: noforbid(); break;
        }
        _id -= 11;
    }
    return _id;
}
