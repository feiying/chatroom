#include <QtGui/QtGui>
#include <QApplication>
#include <QPushButton>
#include <QTcpSocket>
#include "loginwindow.h"
#include "registerpage.h"
#include "serverippage.h"
#include "chatdialog.h"
#include "global.h"


LoginWindow::LoginWindow(QWidget *parent):QDialog(parent)
{
	setupUi(this);
	connect(loginButton,SIGNAL(clicked()),this,SLOT(login()));
	connect(cancelButton,SIGNAL(clicked()),this,SLOT(reject()));
	connect(registerButton,SIGNAL(clicked()),this,SLOT(showregpage()));
	connect(serIPButton,SIGNAL(clicked()),this,SLOT(showservippage()));
	connect(aboutButton,SIGNAL(clicked()),this,SLOT(about()));
	tcpSocket  = new QTcpSocket(this);
	connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(rcv_from_login()));
	//		connect(tcpSocket, SIGNAL(error(QAbstracSocket::SocketError)), this, SLOT(error()));
	tcpSocket->connectToHost(server_ip,server_port);

	regpage = NULL;
	chatpage = NULL;
}
void LoginWindow::rcv_from_login()
{	
	int n;                                                         
	char buf[256];
	bzero(buf,sizeof(buf));
	n = tcpSocket->read(buf,sizeof(buf));
	buf[n]='\0';                                                   
	QString responseLine = QString(buf+4);                         
	get_command(responseLine, command_usr);                        
#ifdef DEBUG
	qDebug() << command_usr.command << command_usr.source << command_usr.target << command_usr.data << endl;
#endif
	if (command_usr.command == "login" && command_usr.data == "ok" ) 
	{
		user_name = usrlineEdit->text();
		gol_tcpSocket  = tcpSocket;
		QMessageBox::information(this,
								 tr("login state"),
								 tr("login sucess press ok to contiune"),
								 QMessageBox::Ok);

		//		show_massage(QString & message);
		disconnect(tcpSocket, SIGNAL(readyRead()), 0, 0);
		/* jmp chat page*/
		showchatpage();
	}
	if (command_usr.command == "login" && command_usr.data == "error" ) 
	{
		QMessageBox::information(this,
								 tr("login state"),
								 tr("fail to login press ok to contiune"),
								 QMessageBox::Ok);
	tcpSocket->close();	
	tcpSocket->connectToHost(server_ip,server_port);
	}
}
void LoginWindow::login()
{
	if (!usrlineEdit->text().isEmpty() && !pwdlineEdit->text().isEmpty())
	{
		command_usr.command = "login";
		command_usr.source = usrlineEdit->text();
		command_usr.target = "server";
		command_usr.data = (usrlineEdit->text()); 
		command_usr.data.append("=");
		command_usr.data.append(pwdlineEdit->text());
		int len = command_usr.command.size()+ 7 + command_usr.source.size() + command_usr.target.size() + command_usr.data.size();
		char buf[5];
		toString(buf,len);
		command_usr.command = buf;
		command_usr.command.append("login");

		//		qDebug() << command_usr.command << command_usr.source << command_usr.target << command_usr.data << endl;
		send_to_server(command_usr, tcpSocket);
	}
	else
	{
		QMessageBox::information(this,
								 tr("ipinput state"),
								 tr("input user_name errror or password errror press ok renew"),
								 QMessageBox::Ok);
#ifdef DEBUG
		qDebug() << "please input usrid and password" << endl;
#endif
	}
}

void LoginWindow::about()
{
	QMessageBox::information(this,
							 tr("About Chart Room"),
							 tr("The Chart Room , Our Team Leader LvShun, the mumbers are ZhaoHan,ZhouHongbo,WangJinfu, HuXiaying,DongJin."),
							 QMessageBox::Yes);
}
void LoginWindow::showchatpage()
{
	if(NULL == chatpage)
		chatpage = new Chat();
	chatpage->show();
	hide();
}
void LoginWindow::showregpage()
{
	if(NULL == regpage)
		regpage= new RegisterPage();
	regpage->show();
	hide();
}
void LoginWindow::showservippage()
{
	if(NULL == serpage)
		serpage= new ServerIPPage();

	serpage->show();
	//	hide();
}
