/********************************************************************************
** Form generated from reading ui file 'serveripwindow.ui'
**
** Created: Thu Oct 9 11:43:04 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SERVERIPWINDOW_H
#define UI_SERVERIPWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

class Ui_ServerIPWindow
{
public:
    QLabel *label;
    QLineEdit *serviplineEdit;
    QLineEdit *portlineEdit;
    QLabel *label_2;
    QPushButton *loginButton;
    QPushButton *loginButton_2;
    QPushButton *okButton_1;
    QPushButton *cancelButton_2;

    void setupUi(QDialog *ServerIPWindow)
    {
    if (ServerIPWindow->objectName().isEmpty())
        ServerIPWindow->setObjectName(QString::fromUtf8("ServerIPWindow"));
    QSize size(300, 158);
    size = size.expandedTo(ServerIPWindow->minimumSizeHint());
    ServerIPWindow->resize(size);
    label = new QLabel(ServerIPWindow);
    label->setObjectName(QString::fromUtf8("label"));
    label->setGeometry(QRect(20, 20, 71, 31));
    QFont font;
    font.setPointSize(13);
    label->setFont(font);
    serviplineEdit = new QLineEdit(ServerIPWindow);
    serviplineEdit->setObjectName(QString::fromUtf8("serviplineEdit"));
    serviplineEdit->setGeometry(QRect(110, 20, 141, 27));
    portlineEdit = new QLineEdit(ServerIPWindow);
    portlineEdit->setObjectName(QString::fromUtf8("portlineEdit"));
    portlineEdit->setGeometry(QRect(110, 60, 141, 27));
    label_2 = new QLabel(ServerIPWindow);
    label_2->setObjectName(QString::fromUtf8("label_2"));
    label_2->setGeometry(QRect(20, 60, 71, 31));
    label_2->setFont(font);
    loginButton = new QPushButton(ServerIPWindow);
    loginButton->setObjectName(QString::fromUtf8("loginButton"));
    loginButton->setGeometry(QRect(60, 170, 80, 31));
    QFont font1;
    font1.setPointSize(11);
    loginButton->setFont(font1);
    loginButton_2 = new QPushButton(ServerIPWindow);
    loginButton_2->setObjectName(QString::fromUtf8("loginButton_2"));
    loginButton_2->setGeometry(QRect(60, 170, 80, 31));
    loginButton_2->setFont(font1);
    okButton_1 = new QPushButton(ServerIPWindow);
    okButton_1->setObjectName(QString::fromUtf8("okButton_1"));
    okButton_1->setGeometry(QRect(30, 110, 91, 41));
    QFont font2;
    font2.setPointSize(15);
    okButton_1->setFont(font2);
    cancelButton_2 = new QPushButton(ServerIPWindow);
    cancelButton_2->setObjectName(QString::fromUtf8("cancelButton_2"));
    cancelButton_2->setGeometry(QRect(150, 110, 91, 41));
    cancelButton_2->setFont(font2);

    retranslateUi(ServerIPWindow);

    QMetaObject::connectSlotsByName(ServerIPWindow);
    } // setupUi

    void retranslateUi(QDialog *ServerIPWindow)
    {
    ServerIPWindow->setWindowTitle(QApplication::translate("ServerIPWindow", "Set Servet IP", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("ServerIPWindow", "ServerIP", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("ServerIPWindow", "port", 0, QApplication::UnicodeUTF8));
    loginButton->setText(QApplication::translate("ServerIPWindow", "Login", 0, QApplication::UnicodeUTF8));
    loginButton_2->setText(QApplication::translate("ServerIPWindow", "Login", 0, QApplication::UnicodeUTF8));
    okButton_1->setText(QApplication::translate("ServerIPWindow", "OK", 0, QApplication::UnicodeUTF8));
    cancelButton_2->setText(QApplication::translate("ServerIPWindow", "Cancel", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(ServerIPWindow);
    } // retranslateUi

};

namespace Ui {
    class ServerIPWindow: public Ui_ServerIPWindow {};
} // namespace Ui

#endif // UI_SERVERIPWINDOW_H
