#include <QtGui/QtGui>
#include <QApplication>
#include <QPushButton>
#include "loginwindow.h"
#include "serverippage.h"
#include "global.h"
#include <QtDebug>

ServerIPPage::ServerIPPage(QWidget *parent):QDialog(parent)
{
	setupUi(this);
	connect(okButton_1,SIGNAL(clicked()),this,SLOT(ip_input()));
	connect(cancelButton_2,SIGNAL(clicked()),this,SLOT(reject()));
	loginwin = NULL;
}

void ServerIPPage::ip_input()
{
	if (!serviplineEdit->text().isEmpty() && !portlineEdit->text().isEmpty())
	{	
		bool ok;
		server_ip = serviplineEdit->text();
		server_port = portlineEdit->text().toInt(&ok,10);
#ifdef DEBUG		
		qDebug() << server_ip;
		qDebug() << server_port;
#endif		
		/* jmp to main page*/
		if(NULL == loginwin)
		{
			loginwin  = new LoginWindow();
			loginwin->show();
		}
	}

	/* error */
	else
	{
		QMessageBox::information(this,
								 tr("ipinput state"),
								 tr("input ip errror or port errror press ok renew"),
								 QMessageBox::Ok);
#ifdef DEBUG		
		qDebug() << "ip error | port error";
#endif		
	}
	hide();
}
