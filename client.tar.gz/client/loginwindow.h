
#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include "ui_loginwindow.h"

#include <QtGui/QWidget>
#include <QDialog>
#include <QTcpSocket>


class QLineEdit;
class RegisterPage;
class ServerIPPage;
class Chat;
class QTcpSocket;

class LoginWindow : public QDialog,public Ui_LoginWindow
{
	Q_OBJECT
public:
		LoginWindow(QWidget *parent=0);
		~LoginWindow(){;}

public :
		RegisterPage *regpage;
		ServerIPPage *serpage;
       Chat        *chatpage;

public slots:
      void showchatpage();
		void showregpage();
		void showservippage();
		void login();
		void rcv_from_login();
		void about();
private:
		QLineEdit *usrLineEdit;
		QLineEdit *pwdLineEdit;
		QTcpSocket *tcpSocket;
};

#endif
