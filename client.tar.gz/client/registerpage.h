
#ifndef REGISTERPAGE_H
#define REGISTERPAGE_H

#include <QtGui/QWidget>
#include <QDialog>
#include <QHostAddress>
#include <QTcpSocket>
#include "ui_registerwindow.h"

class LoginWindow;
class QLineEdit;

class RegisterPage : public QDialog,public Ui_RegisterWindow
{
	Q_OBJECT
public:
	   RegisterPage(QWidget *parent=0);
		   ~RegisterPage(){;}
		   
public :
		LoginWindow *login;
			
			public slots:
			void showLoginWindow();
		void reg_to_server();
		void rcv_from_reg();

private:
		QTcpSocket *tcpSocket;
		QLineEdit *usrLineEdit;
		QLineEdit *pwdLineEdit;
		QLineEdit *rpwdLineEdit;
};
#endif
