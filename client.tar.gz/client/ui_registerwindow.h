/********************************************************************************
** Form generated from reading ui file 'registerwindow.ui'
**
** Created: Thu Oct 9 11:43:04 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_REGISTERWINDOW_H
#define UI_REGISTERWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

class Ui_RegisterWindow
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *usrIdlineEdit;
    QLineEdit *pwdlineEdit;
    QLineEdit *rpwdlineEdit;
    QPushButton *registerButton_1;
    QLabel *label_5;
    QPushButton *cancelButton_1;
    QLabel *label_6;

    void setupUi(QDialog *RegisterWindow)
    {
    if (RegisterWindow->objectName().isEmpty())
        RegisterWindow->setObjectName(QString::fromUtf8("RegisterWindow"));
    QSize size(304, 274);
    size = size.expandedTo(RegisterWindow->minimumSizeHint());
    RegisterWindow->resize(size);
    label = new QLabel(RegisterWindow);
    label->setObjectName(QString::fromUtf8("label"));
    label->setGeometry(QRect(20, 50, 71, 31));
    QFont font;
    font.setPointSize(13);
    label->setFont(font);
    label_2 = new QLabel(RegisterWindow);
    label_2->setObjectName(QString::fromUtf8("label_2"));
    label_2->setGeometry(QRect(20, 100, 81, 31));
    label_2->setFont(font);
    label_3 = new QLabel(RegisterWindow);
    label_3->setObjectName(QString::fromUtf8("label_3"));
    label_3->setGeometry(QRect(10, 10, 181, 31));
    label_3->setFont(font);
    label_4 = new QLabel(RegisterWindow);
    label_4->setObjectName(QString::fromUtf8("label_4"));
    label_4->setGeometry(QRect(20, 150, 81, 31));
    label_4->setFont(font);
    usrIdlineEdit = new QLineEdit(RegisterWindow);
    usrIdlineEdit->setObjectName(QString::fromUtf8("usrIdlineEdit"));
    usrIdlineEdit->setGeometry(QRect(130, 50, 141, 27));
    pwdlineEdit = new QLineEdit(RegisterWindow);
    pwdlineEdit->setObjectName(QString::fromUtf8("pwdlineEdit"));
    pwdlineEdit->setGeometry(QRect(130, 100, 141, 27));
    pwdlineEdit->setEchoMode(QLineEdit::Password);
    rpwdlineEdit = new QLineEdit(RegisterWindow);
    rpwdlineEdit->setObjectName(QString::fromUtf8("rpwdlineEdit"));
    rpwdlineEdit->setGeometry(QRect(130, 150, 141, 27));
    rpwdlineEdit->setEchoMode(QLineEdit::Password);
    registerButton_1 = new QPushButton(RegisterWindow);
    registerButton_1->setObjectName(QString::fromUtf8("registerButton_1"));
    registerButton_1->setGeometry(QRect(20, 210, 101, 41));
    label_5 = new QLabel(RegisterWindow);
    label_5->setObjectName(QString::fromUtf8("label_5"));
    label_5->setGeometry(QRect(140, 80, 141, 18));
    cancelButton_1 = new QPushButton(RegisterWindow);
    cancelButton_1->setObjectName(QString::fromUtf8("cancelButton_1"));
    cancelButton_1->setGeometry(QRect(150, 210, 101, 41));
    label_6 = new QLabel(RegisterWindow);
    label_6->setObjectName(QString::fromUtf8("label_6"));
    label_6->setGeometry(QRect(130, 130, 141, 18));

    retranslateUi(RegisterWindow);

    QMetaObject::connectSlotsByName(RegisterWindow);
    } // setupUi

    void retranslateUi(QDialog *RegisterWindow)
    {
    RegisterWindow->setWindowTitle(QApplication::translate("RegisterWindow", "RegisterWindow", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("RegisterWindow", "UserID", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("RegisterWindow", "PassWord", 0, QApplication::UnicodeUTF8));
    label_3->setText(QApplication::translate("RegisterWindow", "User Information", 0, QApplication::UnicodeUTF8));
    label_4->setText(QApplication::translate("RegisterWindow", "PassWord", 0, QApplication::UnicodeUTF8));
    registerButton_1->setText(QApplication::translate("RegisterWindow", "Register", 0, QApplication::UnicodeUTF8));
    label_5->setText(QApplication::translate("RegisterWindow", "1,2...9 or a,b..z ", 0, QApplication::UnicodeUTF8));
    cancelButton_1->setText(QApplication::translate("RegisterWindow", "back to login", 0, QApplication::UnicodeUTF8));
    label_6->setText(QApplication::translate("RegisterWindow", "the least 6 bit", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(RegisterWindow);
    } // retranslateUi

};

namespace Ui {
    class RegisterWindow: public Ui_RegisterWindow {};
} // namespace Ui

#endif // UI_REGISTERWINDOW_H
