/********************************************************************************
** Form generated from reading ui file 'ChatDialog.ui'
**
** Created: Thu Oct 9 13:01:32 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_CHATDIALOG_H
#define UI_CHATDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QFontComboBox>
#include <QtGui/QFrame>
#include <QtGui/QLabel>
#include <QtGui/QListView>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QToolButton>
#include <QtGui/QWidget>

class Ui_ChatDialog
{
public:
    QTextEdit *chatcontent;
    QTextEdit *sendtext;
    QPushButton *allchat;
    QPushButton *send;
    QPushButton *clear;
    QLabel *towho;
    QPushButton *kick;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QFrame *line_5;
    QFrame *line_6;
    QFrame *line_7;
    QPushButton *quit;
    QPushButton *tohim;
    QFontComboBox *fontComboBox;
    QToolButton *toolButton;
    QToolButton *toolButton_2;
    QComboBox *comboBox;
    QPushButton *invisible;
    QLabel *myname;
    QLabel *state;
    QListView *namelist;
    QListView *forbidlist;
    QPushButton *noauditor;
    QPushButton *auditor;

    void setupUi(QWidget *ChatDialog)
    {
    if (ChatDialog->objectName().isEmpty())
        ChatDialog->setObjectName(QString::fromUtf8("ChatDialog"));
    QSize size(625, 443);
    size = size.expandedTo(ChatDialog->minimumSizeHint());
    ChatDialog->resize(size);
    QPalette palette;
    QBrush brush(QColor(255, 255, 255, 255));
    brush.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Active, QPalette::Base, brush);
    QBrush brush1(QColor(255, 211, 175, 255));
    brush1.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Active, QPalette::Window, brush1);
    QBrush brush2(QColor(0, 170, 0, 255));
    brush2.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Active, QPalette::Highlight, brush2);
    palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
    palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Highlight, brush2);
    palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
    QBrush brush3(QColor(255, 188, 118, 255));
    brush3.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Disabled, QPalette::Highlight, brush3);
    ChatDialog->setPalette(palette);
    ChatDialog->setCursor(QCursor(Qt::PointingHandCursor));
    ChatDialog->setMouseTracking(true);
    ChatDialog->setAutoFillBackground(true);
    chatcontent = new QTextEdit(ChatDialog);
    chatcontent->setObjectName(QString::fromUtf8("chatcontent"));
    chatcontent->setGeometry(QRect(20, 20, 421, 241));
    QPalette palette1;
    QBrush brush4(QColor(170, 170, 0, 255));
    brush4.setStyle(Qt::SolidPattern);
    palette1.setBrush(QPalette::Active, QPalette::WindowText, brush4);
    palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush4);
    QBrush brush5(QColor(127, 125, 123, 255));
    brush5.setStyle(Qt::SolidPattern);
    palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
    chatcontent->setPalette(palette1);
    chatcontent->setReadOnly(true);
    sendtext = new QTextEdit(ChatDialog);
    sendtext->setObjectName(QString::fromUtf8("sendtext"));
    sendtext->setGeometry(QRect(80, 320, 301, 75));
    QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(sendtext->sizePolicy().hasHeightForWidth());
    sendtext->setSizePolicy(sizePolicy);
    sendtext->setSizeIncrement(QSize(0, 0));
    sendtext->setBaseSize(QSize(0, 0));
    QPalette palette2;
    sendtext->setProperty("ss", QVariant(palette2));
    allchat = new QPushButton(ChatDialog);
    allchat->setObjectName(QString::fromUtf8("allchat"));
    allchat->setGeometry(QRect(480, 410, 41, 27));
    QPalette palette3;
    QBrush brush6(QColor(0, 85, 0, 255));
    brush6.setStyle(Qt::SolidPattern);
    palette3.setBrush(QPalette::Active, QPalette::WindowText, brush6);
    QBrush brush7(QColor(170, 170, 143, 255));
    brush7.setStyle(Qt::SolidPattern);
    palette3.setBrush(QPalette::Active, QPalette::Button, brush7);
    QBrush brush8(QColor(85, 0, 0, 255));
    brush8.setStyle(Qt::SolidPattern);
    palette3.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush6);
    palette3.setBrush(QPalette::Inactive, QPalette::Button, brush7);
    palette3.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
    palette3.setBrush(QPalette::Disabled, QPalette::Button, brush7);
    palette3.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    allchat->setPalette(palette3);
    send = new QPushButton(ChatDialog);
    send->setObjectName(QString::fromUtf8("send"));
    send->setGeometry(QRect(390, 350, 50, 26));
    QPalette palette4;
    palette4.setBrush(QPalette::Active, QPalette::WindowText, brush6);
    QBrush brush9(QColor(170, 169, 146, 255));
    brush9.setStyle(Qt::SolidPattern);
    palette4.setBrush(QPalette::Active, QPalette::Button, brush9);
    palette4.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette4.setBrush(QPalette::Active, QPalette::Base, brush);
    palette4.setBrush(QPalette::Active, QPalette::Window, brush8);
    palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush6);
    palette4.setBrush(QPalette::Inactive, QPalette::Button, brush9);
    palette4.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette4.setBrush(QPalette::Inactive, QPalette::Base, brush);
    palette4.setBrush(QPalette::Inactive, QPalette::Window, brush8);
    palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
    palette4.setBrush(QPalette::Disabled, QPalette::Button, brush9);
    palette4.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    palette4.setBrush(QPalette::Disabled, QPalette::Base, brush8);
    palette4.setBrush(QPalette::Disabled, QPalette::Window, brush8);
    send->setPalette(palette4);
    clear = new QPushButton(ChatDialog);
    clear->setObjectName(QString::fromUtf8("clear"));
    clear->setGeometry(QRect(390, 410, 50, 26));
    QPalette palette5;
    palette5.setBrush(QPalette::Active, QPalette::WindowText, brush6);
    palette5.setBrush(QPalette::Active, QPalette::Button, brush9);
    palette5.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette5.setBrush(QPalette::Active, QPalette::Base, brush);
    palette5.setBrush(QPalette::Active, QPalette::Window, brush8);
    palette5.setBrush(QPalette::Inactive, QPalette::WindowText, brush6);
    palette5.setBrush(QPalette::Inactive, QPalette::Button, brush9);
    palette5.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette5.setBrush(QPalette::Inactive, QPalette::Base, brush);
    palette5.setBrush(QPalette::Inactive, QPalette::Window, brush8);
    palette5.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
    palette5.setBrush(QPalette::Disabled, QPalette::Button, brush9);
    palette5.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    palette5.setBrush(QPalette::Disabled, QPalette::Base, brush8);
    palette5.setBrush(QPalette::Disabled, QPalette::Window, brush8);
    clear->setPalette(palette5);
    towho = new QLabel(ChatDialog);
    towho->setObjectName(QString::fromUtf8("towho"));
    towho->setGeometry(QRect(10, 340, 71, 51));
    QPalette palette6;
    QBrush brush10(QColor(170, 170, 127, 255));
    brush10.setStyle(Qt::SolidPattern);
    palette6.setBrush(QPalette::Active, QPalette::Button, brush10);
    palette6.setBrush(QPalette::Active, QPalette::ButtonText, brush4);
    palette6.setBrush(QPalette::Inactive, QPalette::Button, brush10);
    palette6.setBrush(QPalette::Inactive, QPalette::ButtonText, brush4);
    palette6.setBrush(QPalette::Disabled, QPalette::Button, brush10);
    palette6.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    towho->setPalette(palette6);
    QFont font;
    font.setPointSize(13);
    font.setItalic(true);
    towho->setFont(font);
    kick = new QPushButton(ChatDialog);
    kick->setObjectName(QString::fromUtf8("kick"));
    kick->setGeometry(QRect(10, 410, 80, 27));
    QPalette palette7;
    palette7.setBrush(QPalette::Active, QPalette::WindowText, brush6);
    QBrush brush11(QColor(170, 170, 150, 255));
    brush11.setStyle(Qt::SolidPattern);
    palette7.setBrush(QPalette::Active, QPalette::Button, brush11);
    palette7.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette7.setBrush(QPalette::Inactive, QPalette::WindowText, brush6);
    palette7.setBrush(QPalette::Inactive, QPalette::Button, brush11);
    palette7.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette7.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
    palette7.setBrush(QPalette::Disabled, QPalette::Button, brush11);
    palette7.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    kick->setPalette(palette7);
    line = new QFrame(ChatDialog);
    line->setObjectName(QString::fromUtf8("line"));
    line->setGeometry(QRect(440, 10, 20, 431));
    line->setFrameShape(QFrame::VLine);
    line->setFrameShadow(QFrame::Sunken);
    line_2 = new QFrame(ChatDialog);
    line_2->setObjectName(QString::fromUtf8("line_2"));
    line_2->setGeometry(QRect(10, 260, 441, 20));
    line_2->setFrameShape(QFrame::HLine);
    line_2->setFrameShadow(QFrame::Sunken);
    line_3 = new QFrame(ChatDialog);
    line_3->setObjectName(QString::fromUtf8("line_3"));
    line_3->setGeometry(QRect(10, 300, 441, 20));
    line_3->setFrameShape(QFrame::HLine);
    line_3->setFrameShadow(QFrame::Sunken);
    line_4 = new QFrame(ChatDialog);
    line_4->setObjectName(QString::fromUtf8("line_4"));
    line_4->setGeometry(QRect(8, 0, 601, 21));
    line_4->setFrameShape(QFrame::HLine);
    line_4->setFrameShadow(QFrame::Sunken);
    line_5 = new QFrame(ChatDialog);
    line_5->setObjectName(QString::fromUtf8("line_5"));
    line_5->setGeometry(QRect(0, 10, 16, 431));
    line_5->setFrameShape(QFrame::VLine);
    line_5->setFrameShadow(QFrame::Sunken);
    line_6 = new QFrame(ChatDialog);
    line_6->setObjectName(QString::fromUtf8("line_6"));
    line_6->setGeometry(QRect(0, 430, 611, 20));
    line_6->setFrameShape(QFrame::HLine);
    line_6->setFrameShadow(QFrame::Sunken);
    line_7 = new QFrame(ChatDialog);
    line_7->setObjectName(QString::fromUtf8("line_7"));
    line_7->setGeometry(QRect(600, 10, 20, 431));
    line_7->setFrameShape(QFrame::VLine);
    line_7->setFrameShadow(QFrame::Sunken);
    quit = new QPushButton(ChatDialog);
    quit->setObjectName(QString::fromUtf8("quit"));
    quit->setGeometry(QRect(320, 410, 50, 27));
    QPalette palette8;
    palette8.setBrush(QPalette::Active, QPalette::Button, brush9);
    palette8.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette8.setBrush(QPalette::Inactive, QPalette::Button, brush9);
    palette8.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette8.setBrush(QPalette::Disabled, QPalette::Button, brush9);
    palette8.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    quit->setPalette(palette8);
    tohim = new QPushButton(ChatDialog);
    tohim->setObjectName(QString::fromUtf8("tohim"));
    tohim->setGeometry(QRect(538, 410, 41, 27));
    QPalette palette9;
    QBrush brush12(QColor(170, 168, 138, 255));
    brush12.setStyle(Qt::SolidPattern);
    palette9.setBrush(QPalette::Active, QPalette::Button, brush12);
    palette9.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette9.setBrush(QPalette::Inactive, QPalette::Button, brush12);
    palette9.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette9.setBrush(QPalette::Disabled, QPalette::Button, brush12);
    palette9.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    tohim->setPalette(palette9);
    fontComboBox = new QFontComboBox(ChatDialog);
    fontComboBox->setObjectName(QString::fromUtf8("fontComboBox"));
    fontComboBox->setGeometry(QRect(10, 275, 160, 31));
    toolButton = new QToolButton(ChatDialog);
    toolButton->setObjectName(QString::fromUtf8("toolButton"));
    toolButton->setGeometry(QRect(215, 275, 27, 31));
    QFont font1;
    font1.setPointSize(11);
    font1.setBold(true);
    font1.setUnderline(true);
    font1.setWeight(75);
    toolButton->setFont(font1);
    toolButton_2 = new QToolButton(ChatDialog);
    toolButton_2->setObjectName(QString::fromUtf8("toolButton_2"));
    toolButton_2->setGeometry(QRect(242, 275, 27, 31));
    QFont font2;
    font2.setFamily(QString::fromUtf8("Serif"));
    font2.setPointSize(11);
    font2.setBold(true);
    font2.setItalic(true);
    font2.setUnderline(true);
    font2.setWeight(75);
    toolButton_2->setFont(font2);
    comboBox = new QComboBox(ChatDialog);
    comboBox->setObjectName(QString::fromUtf8("comboBox"));
    comboBox->setGeometry(QRect(170, 275, 45, 31));
    invisible = new QPushButton(ChatDialog);
    invisible->setObjectName(QString::fromUtf8("invisible"));
    invisible->setGeometry(QRect(260, 410, 55, 27));
    QPalette palette10;
    palette10.setBrush(QPalette::Active, QPalette::Button, brush9);
    palette10.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette10.setBrush(QPalette::Inactive, QPalette::Button, brush9);
    palette10.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette10.setBrush(QPalette::Disabled, QPalette::Button, brush9);
    palette10.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    invisible->setPalette(palette10);
    myname = new QLabel(ChatDialog);
    myname->setObjectName(QString::fromUtf8("myname"));
    myname->setGeometry(QRect(460, 27, 91, 21));
    state = new QLabel(ChatDialog);
    state->setObjectName(QString::fromUtf8("state"));
    state->setGeometry(QRect(570, 30, 31, 21));
    QFont font3;
    font3.setFamily(QString::fromUtf8("\346\226\260\345\256\213\344\275\223"));
    font3.setPointSize(10);
    font3.setBold(true);
    font3.setWeight(75);
    state->setFont(font3);
    namelist = new QListView(ChatDialog);
    namelist->setObjectName(QString::fromUtf8("namelist"));
    namelist->setGeometry(QRect(454, 51, 151, 291));
    forbidlist = new QListView(ChatDialog);
    forbidlist->setObjectName(QString::fromUtf8("forbidlist"));
    forbidlist->setGeometry(QRect(455, 350, 151, 50));
    noauditor = new QPushButton(ChatDialog);
    noauditor->setObjectName(QString::fromUtf8("noauditor"));
    noauditor->setGeometry(QRect(160, 410, 55, 27));
    QPalette palette11;
    palette11.setBrush(QPalette::Active, QPalette::Button, brush9);
    palette11.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette11.setBrush(QPalette::Inactive, QPalette::Button, brush9);
    palette11.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette11.setBrush(QPalette::Disabled, QPalette::Button, brush9);
    palette11.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    noauditor->setPalette(palette11);
    auditor = new QPushButton(ChatDialog);
    auditor->setObjectName(QString::fromUtf8("auditor"));
    auditor->setGeometry(QRect(100, 410, 55, 27));
    QPalette palette12;
    palette12.setBrush(QPalette::Active, QPalette::Button, brush9);
    palette12.setBrush(QPalette::Active, QPalette::ButtonText, brush8);
    palette12.setBrush(QPalette::Inactive, QPalette::Button, brush9);
    palette12.setBrush(QPalette::Inactive, QPalette::ButtonText, brush8);
    palette12.setBrush(QPalette::Disabled, QPalette::Button, brush9);
    palette12.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
    auditor->setPalette(palette12);

    retranslateUi(ChatDialog);

    QMetaObject::connectSlotsByName(ChatDialog);
    } // setupUi

    void retranslateUi(QWidget *ChatDialog)
    {
    ChatDialog->setWindowTitle(QApplication::translate("ChatDialog", "AKA  \350\201\212\345\244\251\345\256\244", 0, QApplication::UnicodeUTF8));
    allchat->setText(QApplication::translate("ChatDialog", "\347\276\244\350\201\212", 0, QApplication::UnicodeUTF8));
    send->setText(QApplication::translate("ChatDialog", "\345\217\221\351\200\201", 0, QApplication::UnicodeUTF8));
    clear->setText(QApplication::translate("ChatDialog", "\346\270\205\347\251\272", 0, QApplication::UnicodeUTF8));
    towho->setText(QApplication::translate("ChatDialog", "all", 0, QApplication::UnicodeUTF8));
    kick->setText(QApplication::translate("ChatDialog", "\350\270\242\344\272\272", 0, QApplication::UnicodeUTF8));
    quit->setText(QApplication::translate("ChatDialog", "\351\200\200\345\207\272", 0, QApplication::UnicodeUTF8));
    tohim->setText(QApplication::translate("ChatDialog", "\347\247\201\350\201\212", 0, QApplication::UnicodeUTF8));
    toolButton->setText(QApplication::translate("ChatDialog", "B", 0, QApplication::UnicodeUTF8));
    toolButton_2->setText(QApplication::translate("ChatDialog", "I", 0, QApplication::UnicodeUTF8));
    comboBox->clear();
    comboBox->insertItems(0, QStringList()
     << QApplication::translate("ChatDialog", "1", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "2", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "3", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "4", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "5", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "6", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "7", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "8", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "9", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "10", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "11", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "12", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "13", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "14", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "15", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "16", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "17", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "18", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "19", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ChatDialog", "20", 0, QApplication::UnicodeUTF8)
    );
    invisible->setText(QApplication::translate("ChatDialog", "\351\232\220\350\272\253", 0, QApplication::UnicodeUTF8));
    myname->setText(QApplication::translate("ChatDialog", "TextLabel", 0, QApplication::UnicodeUTF8));
    state->setText(QApplication::translate("ChatDialog", "\345\234\250\347\272\277", 0, QApplication::UnicodeUTF8));
    noauditor->setText(QApplication::translate("ChatDialog", "\350\247\243\351\231\244", 0, QApplication::UnicodeUTF8));
    auditor->setText(QApplication::translate("ChatDialog", "\347\246\201\350\250\200", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(ChatDialog);
    } // retranslateUi

};

namespace Ui {
    class ChatDialog: public Ui_ChatDialog {};
} // namespace Ui

#endif // UI_CHATDIALOG_H
