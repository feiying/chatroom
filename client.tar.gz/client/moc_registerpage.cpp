/****************************************************************************
** Meta object code from reading C++ file 'registerpage.h'
**
** Created: Thu Oct 9 11:44:10 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "registerpage.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'registerpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_RegisterPage[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      32,   13,   13,   13, 0x0a,
      48,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_RegisterPage[] = {
    "RegisterPage\0\0showLoginWindow()\0"
    "reg_to_server()\0rcv_from_reg()\0"
};

const QMetaObject RegisterPage::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_RegisterPage,
      qt_meta_data_RegisterPage, 0 }
};

const QMetaObject *RegisterPage::metaObject() const
{
    return &staticMetaObject;
}

void *RegisterPage::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_RegisterPage))
	return static_cast<void*>(const_cast< RegisterPage*>(this));
    if (!strcmp(_clname, "Ui_RegisterWindow"))
	return static_cast< Ui_RegisterWindow*>(const_cast< RegisterPage*>(this));
    return QDialog::qt_metacast(_clname);
}

int RegisterPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: showLoginWindow(); break;
        case 1: reg_to_server(); break;
        case 2: rcv_from_reg(); break;
        }
        _id -= 3;
    }
    return _id;
}
