#include "loginwindow.h"
#include "serverippage.h"
#include "global.h"

command command_usr;
QString server_ip = "192.168.0.170";
quint16 server_port = 8080;
QString user_name;
QTcpSocket *gol_tcpSocket;

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	
	ServerIPPage * serverippage = new ServerIPPage();
	serverippage->show();
	
	app.setQuitOnLastWindowClosed(true);
	return app.exec();
}
