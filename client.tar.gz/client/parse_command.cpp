#include <iostream>
#include <string>
#include "chatdialog.h"
using namespace std;

Command::Command(){}
int Command::parse_command(char * buf)
{
	char *p = NULL;
	char *q = buf;
	int i = 0;

	/** clear the cmdline **/
	bzero(cmd, sizeof(cmd));
	bzero(source, sizeof(source));
	bzero(dest, sizeof(dest));
	bzero(chat_data, sizeof(chat_data));

	while((p = strchr(q,':')) != NULL)
	{
		if(i >= 3)
			break;
		if(i == 0){
			strncpy(cmd, q, p-q);
			cmd[p-q]='\0';
			q = p+1;
		}
		else if(i == 1){
			strncpy(source,q, p-q);
			source[p-q]='\0';
			q = p+1;
		}
		else if(i == 2){
			strncpy(dest,q, p-q);
			dest[p-q]='\0';
			q = p+1;
		}

		i++;
	}
	strcpy(chat_data,q);

	return 0;
}
int Command::toString(char *a, int i)
{
	char tmp[5];
	int j = 0;
	char *p = tmp, *q;
	for(j = 0; j < 5; j++)
		tmp[j] = '0';
	while(1){
			*p = (i%10)+'0';
			p++;
			i = i/10;
			if(i == 0){
						break;
			}
	}
	p = tmp+3;
	for(q = a; p!=tmp-1; q++,p--){
			*q = *p;
		}
	*q='\0';
	return 0;
}
