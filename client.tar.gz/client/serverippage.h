#ifndef _SERVERIPPAGE_H_
#define _SERVERIPPAGE_H_

#include <QtGui/QDialog>
#include <QDialog>
#include "ui_serveripwindow.h"

class LoginWindow;
class QLineEdit;

class ServerIPPage: public QDialog,public Ui_ServerIPWindow                   
{
	Q_OBJECT
public:
		ServerIPPage(QWidget *parent = 0);
		//  ~ServerIPPage();
public :
               LoginWindow *loginwin;
		private slots:
			void ip_input();
			//	void accept();

private:
			QLineEdit *ip_LineEdit;
			QLineEdit *portLineEdit;
};
#endif
