#ifndef _GLOBAL_H_
#define _GLOBAL_H_
//#define DEBUG
class QTcpSocket;
struct command
{
	QString command;
	QString source;
	QString target;
	QString data;
};
extern QString user_name;
extern QTcpSocket *gol_tcpSocket;
extern command command_usr;
extern QString server_ip;
extern quint16 server_port;
int input_check(QString &str);
int get_command(QString &s, command &com_data);
int send_to_server(command &com_data, QTcpSocket * tcp);
int toString(char *a, int i);
#endif
