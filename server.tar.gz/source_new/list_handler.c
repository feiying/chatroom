#include "link.h"
#include "server.h"
#define MAXLINE 2048

int add_user_list(int connfd, char *username, int status)
{
	pthread_t tid;
	tid = pthread_self();
	pthread_mutex_lock(&name_list_mutex);
	insert_node(name_list,tid,connfd,username,status);
	pthread_mutex_unlock(&name_list_mutex);

	return 0;
}
int refresh(int connfd, char *username, char type)
{
	char buf[MAXLINE],name[50];
	int arr[50];
	int count = 0;
	user_link x = NULL;

	if(type == 'A'){
		strcat(buf, "list:#:#:");
		pthread_mutex_lock(&name_list_mutex);
		for(x = name_list->next;x != NULL; x = x->next)
		{
			if(x->status == 0){		/** judge people is online or invisable **/
				strcpy(name,x->user_name);
				strcat(name,"\n");
				strcat(buf,name);
				arr[count] = x->connfd;
				count++;
			}
		}
		buf[strlen(buf)]='\0';
		my_write(connfd, buf, strlen(buf));     /** send the name_list to the login person just now **/
	}
	/** tell the other person who are online that someone login or quit **/
	bzero(buf, sizeof(buf));
	if(type=='A' || type=='R'){  /** someone login or reonline **/
		strcpy(buf, "addlist:#:#:");
	}
	else if(type=='D' || type=='I'){    /** someone quit  or invisable **/
		strcpy(buf, "dellist:#:#:");
	}
	strcat(buf, username);
	buf[strlen(buf)]='\0';
	if(type=='D' || type=='A'){
		for(x = name_list->next;x != NULL; x = x->next){
			if(strcmp(x->user_name, username)!=0){
				my_write(x->connfd, buf, strlen(buf));
			}
		}
	}
	else if(type=='I' || type=='R'){
		for(x = name_list->next;x != NULL; x = x->next){
			if(strcmp(x->user_name, username)!=0 && strcmp(x->user_name, "admin")!=0){
				my_write(x->connfd, buf, strlen(buf));
			}
		}
	}

	/*    for(i = 0; (i < count)&&(); i++)
		  my_write(arr[i],buf,strlen(buf));   */
	pthread_mutex_unlock(&name_list_mutex);

	return 0;
}
int del_user_list(int connfd)
{
	int i;

	pthread_mutex_lock(&name_list_mutex);
	i = delete_node(name_list,connfd);
	pthread_mutex_unlock(&name_list_mutex);

	return i;
}
