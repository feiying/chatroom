#include "server.h"
#include "serverinit.h"
#include "link.h"
#include <time.h>
#define MAXLEN 1024
struct tm *myctime()
{
	time_t t=time(NULL);
	struct tm *tm1=localtime(&t);
	tm1->tm_year+=1900;
	tm1->tm_mon+=1;

	return tm1;

}
int write_chat_record(struct command *cmdline,char *ip)
{
	struct tm *tml;
	tml=myctime();
	char buf[1024];

	pthread_mutex_lock(&chatrecord_mutex);
	sprintf(buf, 
			"[%d-%d-%d %d:%d:%d][%s][%s][%s]:\n%s\n",
			tml->tm_year,tml->tm_mon,tml->tm_mday,tml->tm_hour,tml->tm_min,tml->tm_sec,
			ip,
			cmdline->source,
			cmdline->dest,
			cmdline->data);
	fwrite(buf,sizeof(char),strlen(buf),fp);
	fflush(fp);
	pthread_mutex_unlock(&chatrecord_mutex);
	return 0;
}

int chat(struct user_connect *p, char *username)
{
	int n;
	char buf[MAXLEN];
	char buf_answer[50];
	struct command cmdline;
	user_link u_link;
	while(1){
		n=my_read(p->connfd, buf, MAXLEN);
		if(n <= 0){     /** user quit abnomaly **/
			del_user_list(p->connfd);
			refresh(p->connfd, username, 'D');
			pthread_exit((void *)1);
		}

//		printf("%s\n", buf);

		parse_command(&cmdline, buf);

		if(strcmp(cmdline.cmd, "chat")==0){
			if(strcmp(cmdline.dest, "all")==0){ /** to all **/
				pthread_mutex_lock(&name_list_mutex);
				for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next)
					if(u_link->connfd != p->connfd){
						my_write(u_link->connfd, buf, strlen(buf));
					}

				/** tell the source that the message has sent to all, you can send the next message **/
				bzero(buf_answer, sizeof(buf_answer));
				strcat(buf_answer,"answer:");
				strcat(buf_answer,cmdline.dest);
				strcat(buf_answer,":");
				strcat(buf_answer,cmdline.source);
				strcat(buf_answer,":ok");
				buf_answer[strlen(buf_answer)]='\0';
				my_write(p->connfd, buf_answer, strlen(buf_answer));

				/** write the chat record **/
				write_chat_record(&cmdline,p->ip);
				pthread_mutex_unlock(&name_list_mutex);
			}
			else{   /** to target **/
				pthread_mutex_lock(&name_list_mutex);
				for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next){
					if(strcmp(u_link->user_name, cmdline.dest)==0)
						break;
				}
				pthread_mutex_unlock(&name_list_mutex);
				if(u_link != NULL){
					my_write(u_link->connfd, buf, strlen(buf));
					/** write the chat record **/
					write_chat_record(&cmdline,p->ip);
				}
				else{
					my_write(p->connfd,"the man is not online\n",strlen("the man is not online\n"));
				}
			}
		}
		else if(strcmp(cmdline.cmd, "quit")==0){    /*** user quit normaly ***/
			del_user_list(p->connfd);
			refresh(p->connfd, username, 'D');
			pthread_exit((void *)1);
		}
		else if(strcmp(cmdline.cmd, "answer")==0){  /*** target recive the message ***/
			if(strcmp(cmdline.data, "ok")==0){
				my_write(p->connfd, "receive:#:#:ok", strlen("receive:#:#:ok"));
				pthread_mutex_lock(&name_list_mutex);
				for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next){
					if(strcmp(u_link->user_name, cmdline.dest)==0)
						break;
				}
				pthread_mutex_unlock(&name_list_mutex);
				if(u_link != NULL){
					my_write(u_link->connfd, buf, strlen(buf));
				}
			}
		}

		/*** user invisable request ***/
		else if(strcmp(cmdline.cmd, "invi")==0){    
			//	printf("source=%s\n", cmdline.source);
			//	printf("data=%s\n", cmdline.data);

			pthread_mutex_lock(&name_list_mutex);
			for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next){
				if(strcmp(u_link->user_name, cmdline.source)==0)
					break;
			}
			pthread_mutex_unlock(&name_list_mutex);
			if(u_link != NULL){
				int status_flag = (*(cmdline.data) - '0');
				printf("status_flag=%d\n", status_flag);
				if(status_flag != u_link->status){
					u_link->status = status_flag;
					if(status_flag == 1){		/** invisable **/
						refresh(u_link->connfd, u_link->user_name, 'I');	/** tell other people **/
						my_write(u_link->connfd, "invi:#:#:1ok", strlen("invi:#:#:1ok"));
					}
					else if(status_flag == 0){	/** reonline **/
						refresh(u_link->connfd, u_link->user_name, 'R');	/** tell other people **/
						my_write(u_link->connfd, "invi:#:#:0ok", strlen("invi:#:#:0ok"));
					}
				}

			}
			else
				my_write(u_link->connfd, "invi:#:#:error", strlen("invi:#:#:error"));
		}

		/*** admin kick people ***/
		else if(strcmp(cmdline.cmd, "kick")==0){    
			if(p->admin_flag == 1){
				pthread_mutex_lock(&name_list_mutex);
				for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next){
					if(strcmp(u_link->user_name, cmdline.data)==0)
						break;
				}
				pthread_mutex_unlock(&name_list_mutex);
				if(u_link != NULL){
					my_write(u_link->connfd, "kick:#:#:#", strlen("kick:#:#:#"));
				}
			}
			else{
				/** you are not admin! **/
			}
		}

		/*** admin auditor people ***/
		else if(strcmp(cmdline.cmd, "auditor")==0){    
			if(p->admin_flag == 1){
				pthread_mutex_lock(&name_list_mutex);
				for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next){
					if(strcmp(u_link->user_name, cmdline.dest)==0)
						break;
				}
				pthread_mutex_unlock(&name_list_mutex);
				if(u_link != NULL){
					char tmp[20];
					strcpy(tmp, "auditor:#:#:");
					strcat(tmp, cmdline.data);
					my_write(u_link->connfd, tmp, strlen(tmp));
					//		my_write(p->connfd, tmp, strlen(tmp));
				}
			}
		}

		/*** client auditor answer ***/
		else if(strcmp(cmdline.cmd, "audiok")==0){
			pthread_mutex_lock(&name_list_mutex);
			for(u_link=name_list->next; u_link!=NULL; u_link=u_link->next){
				if(strcmp(u_link->user_name, "admin")==0)
					break;
			}
			pthread_mutex_unlock(&name_list_mutex);
			if(u_link != NULL){
				my_write(u_link->connfd, buf, strlen(buf));
			}
	}    

	/*** wrong input ****/
	else{
		my_write(p->connfd,"the cmd is not chat",strlen("the cmd is not chat"));
		//printf("the command is not chat\n");
	}
	/** clear the buffer **/
	bzero(buf, MAXLEN);

}

return 0;
}
